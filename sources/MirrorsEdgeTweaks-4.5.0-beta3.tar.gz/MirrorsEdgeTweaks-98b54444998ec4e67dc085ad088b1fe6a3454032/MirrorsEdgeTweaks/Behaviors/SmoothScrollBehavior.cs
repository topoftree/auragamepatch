using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace MirrorsEdgeTweaks.Behaviors
{
    public class SmoothScrollBehavior
    {
        private static readonly Dictionary<ScrollViewer, double> _targetOffsets = new Dictionary<ScrollViewer, double>();
        private static readonly Dictionary<ScrollViewer, bool> _isAnimating = new Dictionary<ScrollViewer, bool>();
        private static readonly Dictionary<ScrollViewer, EventHandler> _renderingHandlers = new Dictionary<ScrollViewer, EventHandler>();
        private static readonly Dictionary<ScrollViewer, TimeSpan> _lastRenderTime = new Dictionary<ScrollViewer, TimeSpan>();

        private const double LerpPerFrame = 0.18;
        private const double ReferenceFps = 60.0;

        public static readonly DependencyProperty SmoothScrollProperty =
            DependencyProperty.RegisterAttached(
                "SmoothScroll",
                typeof(bool),
                typeof(SmoothScrollBehavior),
                new PropertyMetadata(false, OnSmoothScrollChanged));

        public static readonly DependencyProperty FadeEdgesProperty =
            DependencyProperty.RegisterAttached(
                "FadeEdges",
                typeof(bool),
                typeof(SmoothScrollBehavior),
                new PropertyMetadata(false, OnFadeEdgesChanged));

        public static bool GetSmoothScroll(DependencyObject obj)
        {
            return (bool)obj.GetValue(SmoothScrollProperty);
        }

        public static void SetSmoothScroll(DependencyObject obj, bool value)
        {
            obj.SetValue(SmoothScrollProperty, value);
        }

        public static bool GetFadeEdges(DependencyObject obj)
        {
            return (bool)obj.GetValue(FadeEdgesProperty);
        }

        public static void SetFadeEdges(DependencyObject obj, bool value)
        {
            obj.SetValue(FadeEdgesProperty, value);
        }

        public static readonly DependencyProperty ShowTopFadeProperty =
            DependencyProperty.RegisterAttached(
                "ShowTopFade", typeof(bool), typeof(SmoothScrollBehavior), new PropertyMetadata(false));

        public static readonly DependencyProperty ShowBottomFadeProperty =
            DependencyProperty.RegisterAttached(
                "ShowBottomFade", typeof(bool), typeof(SmoothScrollBehavior), new PropertyMetadata(false));

        public static bool GetShowTopFade(DependencyObject obj) => (bool)obj.GetValue(ShowTopFadeProperty);
        public static void SetShowTopFade(DependencyObject obj, bool value) => obj.SetValue(ShowTopFadeProperty, value);
        public static bool GetShowBottomFade(DependencyObject obj) => (bool)obj.GetValue(ShowBottomFadeProperty);
        public static void SetShowBottomFade(DependencyObject obj, bool value) => obj.SetValue(ShowBottomFadeProperty, value);

        private static void OnFadeEdgesChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            if (d is ScrollViewer scrollViewer)
            {
                scrollViewer.Loaded -= ScrollViewer_LoadedForFade;
                scrollViewer.ScrollChanged -= ScrollViewer_ScrollChangedForFade;
                scrollViewer.SizeChanged -= ScrollViewer_SizeChanged;

                if ((bool)e.NewValue)
                {
                    scrollViewer.Loaded += ScrollViewer_LoadedForFade;
                    scrollViewer.ScrollChanged += ScrollViewer_ScrollChangedForFade;
                    scrollViewer.SizeChanged += ScrollViewer_SizeChanged;
                }
                else
                {
                    SetShowTopFade(scrollViewer, false);
                    SetShowBottomFade(scrollViewer, false);
                }
            }
        }

        private static void ScrollViewer_LoadedForFade(object sender, RoutedEventArgs e)
        {
            if (sender is ScrollViewer scrollViewer)
            {
                UpdateFade(scrollViewer);
            }
        }

        private static void ScrollViewer_SizeChanged(object sender, SizeChangedEventArgs e)
        {
            if (sender is ScrollViewer scrollViewer)
            {
                UpdateFade(scrollViewer);
            }
        }

        private static void ScrollViewer_ScrollChangedForFade(object sender, ScrollChangedEventArgs e)
        {
            if (sender is ScrollViewer scrollViewer)
            {
                UpdateFade(scrollViewer);
            }
        }

        private static void UpdateFade(ScrollViewer scrollViewer)
        {
            if (scrollViewer.ScrollableHeight == 0)
            {
                SetShowTopFade(scrollViewer, false);
                SetShowBottomFade(scrollViewer, false);
                return;
            }

            bool atTop = scrollViewer.VerticalOffset <= 0.1;
            bool atBottom = scrollViewer.VerticalOffset >= scrollViewer.ScrollableHeight - 0.1;

            SetShowTopFade(scrollViewer, !atTop);
            SetShowBottomFade(scrollViewer, !atBottom);
        }

        private static void OnSmoothScrollChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            if (d is ScrollViewer scrollViewer)
            {
                scrollViewer.PreviewMouseWheel -= ScrollViewer_PreviewMouseWheel;
                scrollViewer.ScrollChanged -= ScrollViewer_ScrollChanged;
                scrollViewer.Unloaded -= ScrollViewer_Unloaded;

                if ((bool)e.NewValue)
                {
                    scrollViewer.PreviewMouseWheel += ScrollViewer_PreviewMouseWheel;
                    scrollViewer.ScrollChanged += ScrollViewer_ScrollChanged;
                    scrollViewer.Unloaded += ScrollViewer_Unloaded;
                }
                else
                {
                    CleanupScrollViewerState(scrollViewer);
                }
            }
        }

        // The static dictionaries hold strong references, so state must be dropped when a
        // ScrollViewer leaves the tree (e.g. tab switch or window close) or it leaks. Entries are
        // lazily re-created by the wheel handler if the viewer is loaded again.
        private static void ScrollViewer_Unloaded(object sender, RoutedEventArgs e)
        {
            if (sender is ScrollViewer scrollViewer)
            {
                CleanupScrollViewerState(scrollViewer);
            }
        }

        private static void CleanupScrollViewerState(ScrollViewer scrollViewer)
        {
            _targetOffsets.Remove(scrollViewer);
            _isAnimating.Remove(scrollViewer);
            _lastRenderTime.Remove(scrollViewer);

            if (_renderingHandlers.TryGetValue(scrollViewer, out var handler))
            {
                CompositionTarget.Rendering -= handler;
                _renderingHandlers.Remove(scrollViewer);
            }
        }

        private static void ScrollViewer_ScrollChanged(object sender, ScrollChangedEventArgs e)
        {
            if (sender is ScrollViewer scrollViewer)
            {
                if (!_isAnimating.ContainsKey(scrollViewer) || !_isAnimating[scrollViewer])
                {
                    if (e.VerticalChange != 0)
                    {
                        _targetOffsets[scrollViewer] = scrollViewer.VerticalOffset;
                    }
                }
            }
        }

        private static void ScrollViewer_PreviewMouseWheel(object sender, MouseWheelEventArgs e)
        {
            if (sender is ScrollViewer scrollViewer)
            {
                if (ShouldIgnoreMouseWheel(e.OriginalSource as DependencyObject, scrollViewer))
                {
                    return;
                }

                if (!_targetOffsets.ContainsKey(scrollViewer))
                {
                    _targetOffsets[scrollViewer] = scrollViewer.VerticalOffset;
                }

                double newTargetOffset = _targetOffsets[scrollViewer] - (e.Delta * 0.5);
                newTargetOffset = Math.Max(0, Math.Min(scrollViewer.ScrollableHeight, newTargetOffset));
                _targetOffsets[scrollViewer] = newTargetOffset;

                if (!_renderingHandlers.ContainsKey(scrollViewer))
                {
                    EventHandler handler = (s, args) => OnRendering(scrollViewer, args);
                    _renderingHandlers[scrollViewer] = handler;
                    _isAnimating[scrollViewer] = true;
                    CompositionTarget.Rendering += handler;
                }
                else if (!_isAnimating.ContainsKey(scrollViewer) || !_isAnimating[scrollViewer])
                {
                    _isAnimating[scrollViewer] = true;
                    CompositionTarget.Rendering += _renderingHandlers[scrollViewer];
                }

                e.Handled = true;
            }
        }

        private static void OnRendering(ScrollViewer scrollViewer, EventArgs args)
        {
            if (!_targetOffsets.ContainsKey(scrollViewer))
            {
                StopAnimation(scrollViewer);
                return;
            }

            double deltaSeconds = 1.0 / ReferenceFps;
            if (args is RenderingEventArgs renderArgs)
            {
                TimeSpan now = renderArgs.RenderingTime;
                if (_lastRenderTime.TryGetValue(scrollViewer, out var last))
                    deltaSeconds = Math.Min((now - last).TotalSeconds, 0.1);
                _lastRenderTime[scrollViewer] = now;
            }

            double current = scrollViewer.VerticalOffset;
            double target = _targetOffsets[scrollViewer];
            double difference = target - current;

            if (Math.Abs(difference) < 0.5)
            {
                scrollViewer.ScrollToVerticalOffset(target);
                StopAnimation(scrollViewer);
                return;
            }

            double factor = 1.0 - Math.Pow(1.0 - LerpPerFrame, deltaSeconds * ReferenceFps);
            double newOffset = current + (difference * factor);
            scrollViewer.ScrollToVerticalOffset(newOffset);
        }

        private static void StopAnimation(ScrollViewer scrollViewer)
        {
            if (_renderingHandlers.ContainsKey(scrollViewer))
            {
                CompositionTarget.Rendering -= _renderingHandlers[scrollViewer];
            }
            _isAnimating[scrollViewer] = false;
            _lastRenderTime.Remove(scrollViewer);
        }

        private static bool ShouldIgnoreMouseWheel(DependencyObject? originalSource, ScrollViewer mainScrollViewer)
        {
            DependencyObject? current = originalSource;

            while (current != null)
            {
                if (current == mainScrollViewer)
                    return false;

                if (current is System.Windows.Controls.ComboBox combo && combo.IsDropDownOpen)
                    return true;

                if (current is ScrollViewer nested && nested != mainScrollViewer
                    && nested.ScrollableHeight > 0
                    && !(nested.TemplatedParent is System.Windows.Controls.TextBox))
                    return true;

                current = GetParent(current);
            }

            return false;
        }

        private static DependencyObject? GetParent(DependencyObject child)
        {
            if (child == null) return null;

            if (child is Visual || child is System.Windows.Media.Media3D.Visual3D)
            {
                var visualParent = VisualTreeHelper.GetParent(child);
                if (visualParent != null) return visualParent;
            }

            return LogicalTreeHelper.GetParent(child);
        }
    }
}

